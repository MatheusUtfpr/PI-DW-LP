package Entidades;

public class EnderecoAula {

    public EnderecoAula(String bairro, String cep) {
        this.bairro = bairro;
        this.cep = cep;
    }
    
    private String bairro;
    private String cep;

    public String getBairro() {
        return bairro;
    }

    public String getCep() {
        return cep;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }
    
    
    }

