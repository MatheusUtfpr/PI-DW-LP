
package Entidades;

public class PessoaAula {
    private String nome;
    private String sobrenome;
    private EnderecoAula endereco;
    
    public PessoaAula (String nome, String sobrenome, EnderecoAula endereco){
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.endereco = endereco;
    }

    public String getNome() {
        return nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public EnderecoAula getEndereco() {
        return endereco;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public void setEndereco(EnderecoAula endereco) {
        this.endereco = endereco;
    }
    
    
}
